package ru.yudnikov.gwt.client;

public class OnceOfflineDataService {
}
