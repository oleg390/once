package ru.yudnikov.gwt.client;

import com.vaadin.shared.communication.ServerRpc;

public interface OncePersistToServerRpc extends ServerRpc {
    void persistToServer();
}
