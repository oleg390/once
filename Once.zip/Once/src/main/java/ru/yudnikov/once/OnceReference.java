package ru.yudnikov.once;

import ru.yudnikov.once.metadata.MetadataCollection;

/**
 * Created by Don on 21.12.2016.
 */
public class OnceReference {

    private String name;
    private MetadataCollection metadataCollection;

    public OnceReference(String string) {
        String[] arr = string.split("\\.");
        if(arr.length == 3) {
            this.name = arr[1] + "." + arr[2];
        }
        switch (arr[1]) {
            case "Справочник": {
                metadataCollection = MetadataCollection.Справочники;
            }
            case "Документ": {
                metadataCollection = MetadataCollection.Документы;
            }
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public MetadataCollection getMetadataCollection() {
        return metadataCollection;
    }

    public void setMetadataCollection(MetadataCollection metadataCollection) {
        this.metadataCollection = metadataCollection;
    }

}
