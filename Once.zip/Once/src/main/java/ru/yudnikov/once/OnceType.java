package ru.yudnikov.once;

import ru.yudnikov.trash.ObjectDescription;

import java.util.Date;

/**
 * Created by Don on 17.09.2016.
 */
public enum OnceType {

    Строка, Число, Дата, Булево, Ссылка, Неопределено;

}
