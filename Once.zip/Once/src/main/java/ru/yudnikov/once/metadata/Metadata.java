package ru.yudnikov.once.metadata;

import ru.yudnikov.once.OnceAdapter;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Don on 22.12.2016.
 */
public class Metadata {

    private static Metadata instance;
    //private static  metaobjectByName;
    private static HashMap<MetadataCollection, ArrayList<Metaobject>> metaobjectsCache = new HashMap<>();
    private static HashMap<String, Metaobject> metaobjectByName = new HashMap<>();

    public Metadata() {

    }

    public static Metadata getInstance() {

        if (instance == null) {
            instance = new Metadata();
            addMetaobjectsFromCollection(MetadataCollection.Справочники);
            addMetaobjectsFromCollection(MetadataCollection.Документы);
        }

        return  instance;

    }

    private static void addMetaobjectsFromCollection(MetadataCollection collection) {
        ArrayList<Metaobject> metaobjects = OnceAdapter.getMetaobjects(collection);
        for (Metaobject m : metaobjects) {
            metaobjectByName.put(m.getName(), m);
        }
        metaobjectsCache.put(collection, metaobjects);
    }

    public HashMap<MetadataCollection, ArrayList<Metaobject>> getMetaobjectsCache() {
        return metaobjectsCache;
    }

    public void setMetaobjectsCache(HashMap<MetadataCollection, ArrayList<Metaobject>> metaobjectsCache) {
        metaobjectsCache = metaobjectsCache;
    }

    public HashMap<String, Metaobject> getMetaobjectByName() {
        return metaobjectByName;
    }

    public void setMetaobjectByName(HashMap<String, Metaobject> metaobjectByName) {
        metaobjectByName = metaobjectByName;
    }

}
