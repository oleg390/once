package ru.yudnikov.once.metadata;

import org.w3c.dom.Node;
import ru.yudnikov.common.XmlParser;
import ru.yudnikov.once.OnceAdapter;
import ru.yudnikov.once.OnceReference;
import ru.yudnikov.once.OnceType;

/**
 * Created by Don on 17.09.2016.
 */
public class PropertyDescription {

    private String name;
    private String representation;
    private Class type;
    private OnceType onceType;
    private OnceReference onceReference;

    public PropertyDescription(Node node) {

        name = node.getNodeName();
        representation = OnceAdapter.getRepresent(node);
        onceType = OnceAdapter.getOnceType(node, this);
        type = OnceAdapter.onceCast(onceType);
    }

    public OnceType getOnceType() {
        return onceType;
    }

    public void setOnceType(OnceType onceType) {
        this.onceType = onceType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRepresentation() {
        return representation;
    }

    public void setRepresentation(String representation) {
        this.representation = representation;
    }

    public Class getType() {
        return type;
    }

    public void setType(Class type) {
        this.type = type;
    }

    public OnceReference getOnceReference() {
        return onceReference;
    }

    public void setOnceReference(OnceReference onceReference) {
        this.onceReference = onceReference;
    }

}
