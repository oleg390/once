package ru.yudnikov.once.metadata;

/**
 * Created by Don on 21.12.2016.
 */
public enum MetadataCollection {

    Справочники, Документы

}
