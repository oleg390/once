package ru.yudnikov.once.metadata;

import org.w3c.dom.Node;
import ru.yudnikov.once.OnceAdapter;

import java.util.ArrayList;

/**
 * Created by Don on 22.12.2016.
 */
public class TableDescription {

    private String name;
    private String representation;
    private ArrayList<PropertyDescription> propertyDescriptions = new ArrayList<>();

    public TableDescription(Node node) {

        name = node.getNodeName();
        representation = OnceAdapter.getRepresent(node);
        propertyDescriptions = OnceAdapter.getPropertyDescriptions(node);

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRepresentation() {
        return representation;
    }

    public void setRepresentation(String representation) {
        this.representation = representation;
    }

    public ArrayList<PropertyDescription> getPropertyDescriptions() {
        return propertyDescriptions;
    }

    public void setPropertyDescriptions(ArrayList<PropertyDescription> propertyDescriptions) {
        this.propertyDescriptions = propertyDescriptions;
    }

}
