package ru.yudnikov.once.metadata;

import org.w3c.dom.Node;
import ru.yudnikov.once.OnceAdapter;

import java.util.ArrayList;

/**
 * Created by Don on 20.12.2016.
 */
public class Metaobject {

    private String name;
    private String representation;
    private MetadataCollection metadataCollection;
    private String detalization;
    private ArrayList<PropertyDescription> propertyDescriptions = new ArrayList<>();
    private ArrayList<TableDescription> tableDescriptions = new ArrayList<>();

    public Metaobject(Node node, String collectionName){

        name = node.getNodeName();
        representation = OnceAdapter.getRepresent(node);
        metadataCollection = MetadataCollection.valueOf(collectionName);
        detalization = "*";
        propertyDescriptions = OnceAdapter.getPropertyDescriptions(node);
        tableDescriptions = OnceAdapter.getTableDescriptions(node);

    }

    public String getDetalization() {
        return detalization;
    }

    public void setDetalization(String detalization) {
        this.detalization = detalization;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRepresentation() {
        return representation;
    }

    public void setRepresentation(String representation) {
        this.representation = representation;
    }

    public MetadataCollection getMetadataCollection() {
        return metadataCollection;
    }

    public ArrayList<PropertyDescription> getPropertyDescriptions() {
        return propertyDescriptions;
    }

    public void setPropertyDescriptions(ArrayList<PropertyDescription> propertyDescriptions) {
        this.propertyDescriptions = propertyDescriptions;
    }

    public ArrayList<TableDescription> getTableDescriptions() {
        return tableDescriptions;
    }

    public void setTableDescriptions(ArrayList<TableDescription> tableDescriptions) {
        this.tableDescriptions = tableDescriptions;
    }
}
