package ru.yudnikov.once;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.ArrayList;

import com.vaadin.addon.touchkit.ui.NavigationButton;
import com.vaadin.addon.touchkit.ui.NumberField;
import com.vaadin.addon.touchkit.ui.Switch;
import com.vaadin.ui.*;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import ru.yudnikov.common.DateUtil;
import ru.yudnikov.common.XmlParser;
import ru.yudnikov.once.metadata.*;
import ru.yudnikov.trash.ObjectDescription;
import ru.yudnikov.ui.ReferenceButton;
import ru.yudnikov.ui.list.CatalogView;
import ru.yudnikov.ui.object.ObjectView;
import ru.yudnikov.ws.OnceExchange;
import ru.yudnikov.ws.OnceExchangePortType;

import static ru.yudnikov.common.DateUtil.getGregorianFromDate;

/**
 * Created by Don on 20.09.2016.
 * RUSSIAN MODULE
 */
public abstract class OnceAdapter {

    private static SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy hh:mm:ss");

    // 4 caching
    public static HashMap<String, ArrayList<Metaobject>> metaobjectsCache = new HashMap<>();
    private static HashMap<String, Metaobject> metaobjectByName = new HashMap<>();

    // Recieving data from 1C web-service

    public static ArrayList<Metaobject> getMetaobjects(MetadataCollection metadataCollection) {

        ArrayList<Metaobject> metaobjects = metaobjectsCache.get(metadataCollection.name());
        if(metaobjects != null) {
            return metaobjects;
        } else {
             metaobjects = new ArrayList<>();
        }

        //System.out.println(Runtime.getRuntime().freeMemory());

        // getting response from 1C
        OnceExchange onceExchange = new OnceExchange();
        OnceExchangePortType port = onceExchange.getOnceExchangeSoap();
        String response = port.getMetaobjects(metadataCollection.name());

        //System.out.println(response);

        // parsing XML
        Element root = XmlParser.getRootElement(response);
        Node node = root.getChildNodes().item(0).getNextSibling();
        NodeList nodes = node.getChildNodes();
        for (int i = 0; i < nodes.getLength(); i++) {
            node = nodes.item(i);
            if(node.getNodeType()!= 1) {
                continue;
            }

            // Making metaobject from xml node
            Metaobject metaobject = new Metaobject(node, metadataCollection.name());
            metaobjects.add(metaobject);

            metaobjectByName.put(metaobject.getName(), metaobject);

        }

        metaobjectsCache.put(metadataCollection.name(), metaobjects);

        return metaobjects;

    }

    public static ArrayList<Reference> getJournal(Metaobject metaobject) {

        Date endPeriod = new Date();
        Date beginPeriod = DateUtil.addMonths(endPeriod, -120);

        ArrayList<Reference> references = new ArrayList<>();

        // getting response from 1C
        OnceExchange onceExchange = new OnceExchange();
        OnceExchangePortType port = onceExchange.getOnceExchangeSoap();
        String response = port.getJournal(
                metaobject.getName(),
                metaobject.getDetalization(),
                getGregorianFromDate(DateUtil.bginningOfDay(beginPeriod)),
                getGregorianFromDate(DateUtil.endOfDay(endPeriod)),
                0
        );

        //System.out.println(response);

        // parsing XML
        Element root = XmlParser.getRootElement(response);
        NodeList nodes = root.getChildNodes();

        addReference(metaobject, references, nodes);

        return references;

    }

    private static void addReference(Metaobject metaobject, ArrayList<Reference> references, NodeList nodes) {
        for (int i = 0; i < nodes.getLength(); i++) {
            Node node = nodes.item(i);
            if(node.getNodeType()!= 1) {
                continue;
            }
            Reference reference = new Reference(node, metaobject);
            references.add(reference);
            //System.out.println(reference.getRepresentation());
        }
    }

    public static ArrayList<Reference> getCatalog(Metaobject metaobject) {

        ArrayList<Reference> references = new ArrayList<>();

        if(metaobject == null) {
            return references;
        }

        // getting response from 1C
        OnceExchange onceExchange = new OnceExchange();
        OnceExchangePortType port = onceExchange.getOnceExchangeSoap();
        String response = port.getCatalog(metaobject.getName());

        // parsing XML
        Element root = XmlParser.getRootElement(response);
        NodeList nodes = root.getChildNodes();

        addReference(metaobject, references, nodes);

        return references;

    }

    public static ArrayList<Component> getObjectFields(final Reference reference, final ObjectView currentView) {

        ArrayList<Component> components = new ArrayList<>();

        // getting response from 1C
        OnceExchange onceExchange = new OnceExchange();
        final OnceExchangePortType port = onceExchange.getOnceExchangeSoap();
        String response = port.getObject(reference.getMetaobject().getName(), reference.getId().toString());

        final Element root = XmlParser.getRootElement(response);
        Node mainNode = XmlParser.getChildByName(root, reference.getMetaobject().getName() + "." + reference.getId().toString());
        //NodeList nodes = mainNode.getChildNodes();

        for (final PropertyDescription p : reference.getMetaobject().getPropertyDescriptions()) {
            final Node node = XmlParser.getChildByName(mainNode, p.getName());

            Component component = null;

            switch (p.getOnceType()) {

                case Строка:
                    TextField textField = new TextField(p.getRepresentation());
                    textField.setValue(node.getTextContent());
                    component = textField;
                    break;
                case Число:
                    NumberField numberField = new NumberField(p.getRepresentation());
                    numberField.setValue(node.getTextContent());
                    component = numberField;
                    break;
                case Дата:
                    DateField dateField = new DateField(p.getRepresentation());
                    dateField.setValue(onceDate(node.getTextContent()));
                    component = dateField;
                    break;
                case Булево:
                    //CheckBox checkBox = new CheckBox();
                    Switch componentSwitch = new Switch(p.getRepresentation());
                    break;
                case Ссылка:
                    try {
                        component = getComponent(currentView, components, root, p, node);
                    }
                    catch (Exception e) {

                    }
                    break;
                case Неопределено:
                    break;

            }
            if(component != null) {
                components.add(component);
            }
        }

        return components;

    }

    private static Component getComponent(final ObjectView currentView, ArrayList<Component> components, Element root, PropertyDescription p, Node node) {
        Component component;
        components.add(new Label(p.getRepresentation() + ":"));

        Metaobject m = metaobjectByName.get(p.getOnceReference().getName());

        NodeList nodeList = root.getElementsByTagName(node.getTextContent());
        Reference ref = null;
        if(nodeList.getLength() == 0) {
            ref= new Reference(m);
        } else {
            ref = new Reference(nodeList.item(0), m);
        }

        final ReferenceButton navigationButton = new ReferenceButton(p, ref);
        navigationButton.addClickListener(new NavigationButton.NavigationButtonClickListener() {
            @Override
            public void buttonClick(NavigationButton.NavigationButtonClickEvent navigationButtonClickEvent) {
                //Metaobject m = metaobjectByName.get(navigationButton.getPropertyDescription().getOnceReference().getName());
                Metaobject m = navigationButton.getReference().getMetaobject();
                currentView.setCurrentComponent(navigationButton);
                currentView.getNavigationManager().navigateTo(new CatalogView(m, true, currentView));
            }
        });
        component = navigationButton;
        return component;
    }

    public static ArrayList<PropertyDescription> getPropertyDescriptions(Node node) {

        ArrayList<PropertyDescription> propertyDescriptions = new ArrayList<>();

        Node propertiesNode = XmlParser.getChildByName(node, "Реквизиты");
        NodeList properties = null;
        if (propertiesNode == null) {
            properties = node.getChildNodes();
        } else {
            properties = propertiesNode.getChildNodes();
        }

        for (int i = 0; i < properties.getLength(); i++) {
            Node propertyNode = properties.item(i);
            if (propertyNode.getNodeType() != 1) {
                continue;
            }

            propertyDescriptions.add(new PropertyDescription(propertyNode));

        }

        return propertyDescriptions;

    }

    public static ArrayList<TableDescription> getTableDescriptions(Node node) {

        ArrayList<TableDescription> tableDescriptions = new ArrayList<>();

        Node tablesNode = XmlParser.getChildByName(node, "ТабличныеЧасти");
        NodeList tables = tablesNode.getChildNodes();

        for (int i = 0; i < tables.getLength(); i++) {
            Node tableNode = tables.item(i);
            if (tableNode.getNodeType() != 1) {
                continue;
            }

            tableDescriptions.add(new TableDescription(tableNode));

        }

        return tableDescriptions;

    }

    public static Reference getNomenclature(String barcode) {

        Metaobject m = Metadata.getInstance().getMetaobjectByName().get("Справочник.Номенклатура");
        Reference reference = new Reference(m);

        OnceExchange onceExchange = new OnceExchange();
        OnceExchangePortType port = onceExchange.getOnceExchangeSoap();
        String response = port.getNomenclature(barcode);

        if(response.equals("")) {
            return reference;
        }

        Element root = XmlParser.getRootElement(response);

        reference = new Reference(root.getFirstChild().getNextSibling(), m);

        return reference;
    }

    // Overriding some 1C logic

    public static String getRefRepresent(Node node, Metaobject metaobject) {

        String represent = "";

        switch (metaobject.getMetadataCollection()) {
            case Справочники: {
                represent = XmlParser.getChildByName(node, "Наименование").getTextContent();
                break;
            }
            case Документы: {
                represent = XmlParser.getChildByName(node, "Номер").getTextContent();
                break;
            }
        }

        return represent;

    }

    public static String getRepresent(Node node) {

        try {
            return XmlParser.getChildByName(node, "Синоним").getTextContent();
        }
        catch (Exception e) {
            return "";
        }

    }

    public static OnceType getOnceType(Node node, PropertyDescription propertyDescription) {

        Boolean monotype = getBooleanValue(XmlParser.getChildByName(node, "Монотип").getTextContent());

        if(!monotype) {
            // bad...
        }

        try {
            String textContent = XmlParser.getChildByName(node, "Типы").getFirstChild().getNextSibling().getTextContent();
            OnceType onceType = OnceType.valueOf(textContent.split("\\.")[0]);
            if(onceType == OnceType.Ссылка) {
                propertyDescription.setOnceReference(new OnceReference(textContent));
            }
            return onceType;
        }
        catch (Exception e) {

        }
        return OnceType.Неопределено;

    }

    public static boolean getBooleanValue(String string) {

        if(string.equals("Да")) {
            return true;
        }

        return false;

    }

    public static Class onceCast(OnceType onceType) {

        Class type = String.class;

        switch (onceType) {
            case Строка:
                return String.class;
            case Число:
                return Integer.class;
            case Дата:
                return Date.class;
            case Булево:
                return Boolean.class;
            case Ссылка:
                return Reference.class;
        }

        return type;

    }

    // Date format...

    public static Date onceDate(String string) {

        Date date = new Date();

        try {
            date = dateFormat.parse(string);
        }
        catch (ParseException e) {
            e.printStackTrace();
        }

        return date;

    }

    public static String onceDateString(Date date) {

        return dateFormat.format(date);

    }

}
