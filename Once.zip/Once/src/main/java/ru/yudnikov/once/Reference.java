package ru.yudnikov.once;

import org.w3c.dom.Node;
import ru.yudnikov.once.metadata.Metaobject;

import java.util.UUID;


/**
 * Created by Don on 20.12.2016.
 */
public class Reference {

    private UUID id;
    private Metaobject metaobject;
    private String representation;
    private boolean isEmpety;

    public Reference(Node node, Metaobject m) {

        String[] arr = node.getNodeName().split("\\.");

        if(arr[2].equals("ПустаяСсылка")) {
            id = null;
            representation = "<>";
            isEmpety = true;
        } else {
            id = UUID.fromString(arr[2]);
            representation = OnceAdapter.getRefRepresent(node, m);
            isEmpety = false;
        }
        metaobject = m;

    }

    public Reference(Metaobject m) {

        id = null;
        representation = "<>";
        metaobject = m;
        isEmpety = true;

    }

    @Override
    public String toString(){
        return representation;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Metaobject getMetaobject() {
        return metaobject;
    }

    public void setMetaobject(Metaobject metaobject) {
        this.metaobject = metaobject;
    }

    public String getRepresentation() {
        return representation;
    }

    public void setRepresentation(String representation) {
        this.representation = representation;
    }

    public boolean isEmpety() {
        return isEmpety;
    }

    public void setEmpety(boolean empety) {
        isEmpety = empety;
    }
}
