package ru.yudnikov.common;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.ByteArrayInputStream;
import java.io.IOException;

/**
 * Created by Don on 17.09.2016.
 */
public abstract class XmlParser {

    public static Document getDocumentFromString(String string) {

        Document document = null;

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            document = builder.parse(new InputSource(new ByteArrayInputStream(string.getBytes("windows-1251"))));
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return document;

    }

    public static Element getRootElement(String string) {

        Document document = getDocumentFromString(string);
        return document.getDocumentElement();

    }

    public static Node getChildByName(Node parent, String name) {
        for(Node child = parent.getFirstChild(); child != null; child = child.getNextSibling())
        {
            if(child instanceof Node && name.equals(child.getNodeName())) {
                return child;
            }
        }
        return null;
    }

    public static Node getChildByName(Node parent, String name, short nodeType) {
        for(Node child = parent.getFirstChild(); child != null; child = child.getNextSibling())
        {
            if(child instanceof Node && name.equals(child.getNodeName()) && child.getNodeType() == nodeType) {
                return child;
            }
        }
        return null;
    }

}
