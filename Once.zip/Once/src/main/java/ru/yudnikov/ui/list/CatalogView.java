package ru.yudnikov.ui.list;

import com.vaadin.addon.touchkit.ui.NavigationButton;
import com.vaadin.addon.touchkit.ui.NavigationView;
import com.vaadin.addon.touchkit.ui.Toolbar;
import com.vaadin.addon.touchkit.ui.VerticalComponentGroup;
import com.vaadin.data.Property;
import com.vaadin.event.FieldEvents;
import com.vaadin.ui.Component;
import com.vaadin.ui.TextField;
import ru.yudnikov.once.OnceAdapter;
import ru.yudnikov.once.Reference;
import ru.yudnikov.once.metadata.Metaobject;
import ru.yudnikov.ui.ReferenceButton;
import ru.yudnikov.ui.object.ObjectView;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

/**
 * Created by Don on 20.12.2016.
 */
public class CatalogView extends NavigationView {

    public CatalogView(Metaobject metaobject) {

        final VerticalComponentGroup content = new VerticalComponentGroup();

        ArrayList<Reference> references = OnceAdapter.getCatalog(metaobject);
        for(final Reference r : references) {
            NavigationButton button = new NavigationButton(r.getRepresentation());
            button.addClickListener(new NavigationButton.NavigationButtonClickListener() {
                @Override
                public void buttonClick(NavigationButton.NavigationButtonClickEvent navigationButtonClickEvent) {

                    getNavigationManager().navigateTo(new ObjectView(r));

                }
            });
            content.addComponent(button);
        }

        setCaption(metaobject.getRepresentation());
        setContent(content);

    }

    public CatalogView(Metaobject metaobject, boolean selectionMode, final ObjectView previousView) {

        super();

        final VerticalComponentGroup content = new VerticalComponentGroup();

        ArrayList<Reference> references = OnceAdapter.getCatalog(metaobject);
        for(final Reference r : references) {
            NavigationButton button = new NavigationButton(r.getRepresentation());
            button.addClickListener(new NavigationButton.NavigationButtonClickListener() {
                @Override
                public void buttonClick(NavigationButton.NavigationButtonClickEvent navigationButtonClickEvent) {

                    getNavigationManager().navigateTo(previousView);
                    if(ReferenceButton.class.isInstance(previousView.getCurrentComponent())) {
                        ReferenceButton referenceButton = (ReferenceButton) previousView.getCurrentComponent();
                        referenceButton.setReference(r);
                    }
                    previousView.getCurrentComponent().setCaption(r.getRepresentation());
                    try {
                        TimeUnit.MILLISECONDS.sleep(1000);
                    }
                    catch (Exception e) {

                    }

                }
            });
            content.addComponent(button);
        }

        setCaption(metaobject.getRepresentation());
        setContent(content);

    }

}
