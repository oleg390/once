package ru.yudnikov.ui.object.table;

import com.vaadin.addon.touchkit.ui.*;
import com.vaadin.event.FieldEvents;
import com.vaadin.ui.Table;
import com.vaadin.ui.TextField;
import ru.yudnikov.once.OnceAdapter;
import ru.yudnikov.once.Reference;
import ru.yudnikov.once.metadata.Metaobject;
import ru.yudnikov.once.metadata.PropertyDescription;
import ru.yudnikov.once.metadata.TableDescription;

import java.util.HashMap;
import java.util.UUID;

/**
 * Created by Don on 23.12.2016.
 */
public class TableView extends NavigationView {

    private HashMap<UUID, Integer> cache = new HashMap<>();

    private TableDescription tableDescription;
    final Table table;
    private int i = 0;

    public TableView(Reference r, TableDescription t) {

        VerticalComponentGroup layout = new VerticalComponentGroup();

        table = new Table(t.getName());
        table.setWidth("100%");
        table.setSelectable(true);

        for (PropertyDescription p : t.getPropertyDescriptions()) {
            table.addContainerProperty(p.getName(), p.getType(), null);
        }

        layout.addComponent(table);

        setCaption(t.getName());
        setContent(layout);

        Toolbar toolbar = new Toolbar();

        final NumberField numberField = new NumberField();
        numberField.setValue("1");
        numberField.setWidth("25%");

        final TextField textField = new TextField();
        textField.setWidth("75%");
        textField.addTextChangeListener(
                new FieldEvents.TextChangeListener() {
                    @Override
                    public void textChange(FieldEvents.TextChangeEvent event) {
                        String text = event.getText();
                        Reference reference = OnceAdapter.getNomenclature(text);
                        if(reference.isEmpety()){
                            return;
                        }

                        int newQuantity = Integer.parseInt(numberField.getValue());

                        if(cache.get(reference.getId()) == null) {
                            table.addItem(new Object[]{newQuantity, reference}, i);
                            cache.put(reference.getId(), i++);
                        } else {
                            int j = cache.get(reference.getId());
                            int q = (int) table.getItem(j).getItemProperty("Количество").getValue();
                            table.getItem(j).getItemProperty("Количество").setValue(q + newQuantity);
                        }

                        textField.setValue("");
                    }
                }
        );
        toolbar.addComponents(textField, numberField);

        setToolbar(toolbar);

    }

}
