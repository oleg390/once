package ru.yudnikov.ui.metaobjects;

import com.vaadin.addon.touchkit.ui.NavigationButton;
import com.vaadin.addon.touchkit.ui.NavigationView;
import com.vaadin.addon.touchkit.ui.VerticalComponentGroup;
import ru.yudnikov.once.OnceAdapter;
import ru.yudnikov.once.metadata.Metadata;
import ru.yudnikov.once.metadata.MetadataCollection;
import ru.yudnikov.once.metadata.Metaobject;
import ru.yudnikov.ui.SearchableView;
import ru.yudnikov.ui.list.CatalogView;
import ru.yudnikov.ui.list.JornalView;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Don on 20.12.2016.
 */
public class MetaobjectsView extends SearchableView {

    private static HashMap<MetadataCollection, Class<?>> map = new HashMap<>();
    static {
        map.put(MetadataCollection.Справочники, CatalogView.class);
        map.put(MetadataCollection.Документы, JornalView.class);
    }

    public MetaobjectsView(final MetadataCollection collection) {

        super();

        final VerticalComponentGroup content = new VerticalComponentGroup();

        //ArrayList<Metaobject> metaobjects = OnceAdapter.getMetaobjects(collectionName);
        ArrayList<Metaobject> metaobjects = Metadata.getInstance().getMetaobjectsCache().get(collection);
        for(final Metaobject m : metaobjects) {
            NavigationButton button = new NavigationButton(m.getRepresentation());
            button.addClickListener(new NavigationButton.NavigationButtonClickListener() {
                @Override
                public void buttonClick(NavigationButton.NavigationButtonClickEvent navigationButtonClickEvent) {

                    Class type = map.get(collection);
                    try {
                        Constructor<?> ctor = type.getConstructor(Metaobject.class);
                        Object view = ctor.newInstance(new Object[] { m });
                        getNavigationManager().navigateTo((NavigationView) view);
                    } catch (Exception e) {
                        return;
                    }

                }
            });
            content.addComponent(button);
        }

        setCaption(collection.name());
        setContent(content);

    }

}
