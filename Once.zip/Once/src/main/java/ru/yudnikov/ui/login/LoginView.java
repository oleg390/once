package ru.yudnikov.ui.login;

import com.vaadin.addon.touchkit.ui.NavigationView;
import com.vaadin.addon.touchkit.ui.VerticalComponentGroup;
import com.vaadin.ui.*;

/**
 * Created by Don on 20.12.2016.
 */
public class LoginView extends NavigationView {

    private boolean isAuthorized;
    private VerticalComponentGroup layout = new VerticalComponentGroup();

    public LoginView() {

        drawLayout();

    }

    public void drawLayout(){

        layout.removeAllComponents();

        if(isAuthorized) {

            setCaption("Текущий пользователь");
            Label label = new Label("#имя");
            layout.addComponent(label);
            Button logoutButton = new Button("Выйти");
            logoutButton.addClickListener(new Button.ClickListener() {
                @Override
                public void buttonClick(Button.ClickEvent event) {
                    isAuthorized = false;
                    drawLayout();
                }
            });

            layout.addComponent(logoutButton);

        } else {

            setCaption("Авторизация");
            TextField logiField = new TextField("Имя пользователя");
            layout.addComponent(logiField);
            PasswordField passwordField = new PasswordField("Пароль");
            layout.addComponent(passwordField);
            Button submitButton = new Button("ОК");
            submitButton.addClickListener(new Button.ClickListener() {
                @Override
                public void buttonClick(Button.ClickEvent event) {
                    isAuthorized = true;
                    drawLayout();
                }
            });
            layout.addComponent(submitButton);

        }

        setContent(layout);

    }

    public boolean isAuthorized() {
        return isAuthorized;
    }

    public void setAuthorized(boolean authorized) {
        isAuthorized = authorized;
    }

}
