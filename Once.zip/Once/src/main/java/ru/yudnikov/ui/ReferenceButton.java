package ru.yudnikov.ui;

import com.vaadin.addon.touchkit.ui.NavigationButton;
import ru.yudnikov.once.Reference;
import ru.yudnikov.once.metadata.PropertyDescription;

/**
 * Created by Don on 21.12.2016.
 */
public class ReferenceButton extends NavigationButton {

    private PropertyDescription propertyDescription;
    private Reference reference;

    public ReferenceButton(PropertyDescription p, Reference r) {
        super(r.getRepresentation());
        reference = r;
        propertyDescription = p;
    }

    public ReferenceButton(String string, PropertyDescription p) {
        super(string);
        propertyDescription = p;
    }

    public PropertyDescription getPropertyDescription() {
        return propertyDescription;
    }

    public void setPropertyDescription(PropertyDescription propertyDescription) {
        this.propertyDescription = propertyDescription;
    }

    public Reference getReference() {
        return reference;
    }

    public void setReference(Reference reference) {
        this.reference = reference;
    }



}
