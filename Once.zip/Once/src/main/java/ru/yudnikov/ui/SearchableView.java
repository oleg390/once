package ru.yudnikov.ui;

import com.vaadin.addon.touchkit.ui.NavigationView;
import com.vaadin.addon.touchkit.ui.Toolbar;
import com.vaadin.addon.touchkit.ui.VerticalComponentGroup;
import com.vaadin.event.FieldEvents;
import com.vaadin.ui.Component;
import com.vaadin.ui.TextField;

/**
 * Created by Don on 26.12.2016.
 */
public class SearchableView extends NavigationView{

    public SearchableView() {

        Toolbar toolbar = new Toolbar();
        final TextField searchField = new TextField("Поиск");
        searchField.setWidth("100%");
        searchField.addTextChangeListener(new FieldEvents.TextChangeListener() {
            @Override
            public void textChange(FieldEvents.TextChangeEvent event) {
                //System.out.println();
                String text = event.getText();
                VerticalComponentGroup verticalComponentGroup = (VerticalComponentGroup) getContent();
                for (Component c : verticalComponentGroup) {
                    if(c.getCaption().toLowerCase().contains(text.toLowerCase())) {
                        c.setVisible(true);
                    } else {
                        c.setVisible(false);
                    }
                }
            }
        });

        toolbar.addComponent(
                searchField
        );

        setToolbar(toolbar);

    }

}
