package ru.yudnikov.ui.main;

import com.vaadin.addon.touchkit.ui.NavigationButton;
import com.vaadin.addon.touchkit.ui.NavigationView;
import com.vaadin.addon.touchkit.ui.VerticalComponentGroup;
import ru.yudnikov.once.metadata.Metadata;
import ru.yudnikov.once.metadata.MetadataCollection;
import ru.yudnikov.ui.metaobjects.MetaobjectsView;

import java.util.ArrayList;

/**
 * Created by Don on 20.12.2016.
 */
public class MainView extends NavigationView {

    public MainView() {

        //initializing metadata
        Metadata.getInstance();

        ArrayList<MetadataCollection> MetaobjectsList = new ArrayList<>();
        MetaobjectsList.add(MetadataCollection.Справочники);
        MetaobjectsList.add(MetadataCollection.Документы);

        setCaption("Главное меню");

        final VerticalComponentGroup content = new VerticalComponentGroup();

        for (final MetadataCollection collection : MetaobjectsList) {
            NavigationButton newButton = new NavigationButton();
            newButton.setCaption(collection.name());
            newButton.addClickListener(new NavigationButton.NavigationButtonClickListener() {
                @Override
                public void buttonClick(NavigationButton.NavigationButtonClickEvent event) {
                    getNavigationManager().navigateTo(new MetaobjectsView(collection));
                }
            });
            content.addComponent(newButton);
        }

        setContent(content);

    }

}
