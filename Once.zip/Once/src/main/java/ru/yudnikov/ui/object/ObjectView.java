package ru.yudnikov.ui.object;

import com.vaadin.addon.touchkit.ui.NavigationButton;
import com.vaadin.addon.touchkit.ui.NavigationView;
import com.vaadin.addon.touchkit.ui.Toolbar;
import com.vaadin.addon.touchkit.ui.VerticalComponentGroup;
import com.vaadin.server.FontAwesome;
import com.vaadin.ui.Button;
import com.vaadin.ui.Component;
import ru.yudnikov.once.OnceAdapter;
import ru.yudnikov.once.Reference;
import ru.yudnikov.once.metadata.TableDescription;
import ru.yudnikov.ui.object.table.TableView;

import java.util.ArrayList;
import java.util.HashMap;

public class ObjectView extends NavigationView {

    private Component currentComponent;
    private HashMap<TableDescription, NavigationView> cache = new HashMap<>();

    public ObjectView(final Reference reference) {

        VerticalComponentGroup layout = new VerticalComponentGroup();

        ArrayList<Component> components = OnceAdapter.getObjectFields(reference, this);

        for(Component c : components) {
            layout.addComponent(c);
        }

        ArrayList<TableDescription> tableDescriptions = reference.getMetaobject().getTableDescriptions();

        if(tableDescriptions.size() > 0) {
            final TableDescription tableDescription = tableDescriptions.get(0);
            NavigationButton navigationButton = new NavigationButton(tableDescription.getName());
            navigationButton.addClickListener(new NavigationButton.NavigationButtonClickListener() {
                @Override
                public void buttonClick(NavigationButton.NavigationButtonClickEvent navigationButtonClickEvent) {
                    if(cache.get(tableDescription) == null) {
                        cache.put(tableDescription, new TableView(reference, tableDescription));
                    }
                    getNavigationManager().navigateTo(cache.get(tableDescription));
                }
            });
            getNavigationBar().setRightComponent(navigationButton);
        }

        setCaption(reference.getRepresentation());
        setContent(layout);

        Toolbar toolbar = new Toolbar();
        Button saveButton = new Button("Записать");
        saveButton.setIcon(FontAwesome.SAVE);

        toolbar.addComponent(saveButton);

        setToolbar(toolbar);

    }

    public Component getCurrentComponent() {
        return currentComponent;
    }

    public void setCurrentComponent(Component currentComponent) {
        this.currentComponent = currentComponent;
    }

}
