@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.yudnikov.ru/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package ru.yudnikov.ws;
